"""Dependency-light document and link checks. Usage: python tests/static_audit.py"""
from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urlparse, unquote
import sys, subprocess
ROOT=Path(__file__).resolve().parents[1]

class PageParser(HTMLParser):
 def __init__(self):
  super().__init__();self.ids=[];self.links=[];self.h1=0;self.titles=0;self.meta_desc=0;self.main=0;self.skip=False;self.nav=0
 def handle_starttag(self,t,attrs):
  a=dict(attrs)
  if 'id' in a:self.ids.append(a['id'])
  if t=='h1':self.h1+=1
  if t=='title':self.titles+=1
  if t=='main':self.main+=1
  if t=='nav' and a.get('aria-label')=='Primary navigation':self.nav+=1
  if t=='meta' and a.get('name')=='description':self.meta_desc+=1
  if t=='a' and a.get('class')=='skip-link':self.skip=True
  for k in ['href','src']:
   if t in ('a','img','link','script') and k in a:self.links.append(a[k])

def audit():
 fails=[];htmls=sorted(ROOT.rglob('*.html'))
 for p in htmls:
  parser=PageParser();parser.feed(p.read_text(encoding='utf-8'))
  for label,cond in [('one H1',parser.h1==1),('one main',parser.main==1),('one title',parser.titles==1),('description',parser.meta_desc==1),('skip link',parser.skip),('primary nav',parser.nav==1),('unique ids',len(parser.ids)==len(set(parser.ids)))]:
   if not cond:fails.append(f'{p.relative_to(ROOT)}: {label}')
  for link in parser.links:
   if not link or link.startswith(('http://','https://','mailto:','tel:','data:','javascript:','#')):continue
   target=unquote(link.split('#')[0].split('?')[0])
   if not (p.parent/target).exists():fails.append(f'{p.relative_to(ROOT)}: missing {link}')
 for anchor_page in [ROOT/'projects.html',ROOT/'projects/battery-digital-twin.html']:
  parser=PageParser();parser.feed(anchor_page.read_text(encoding='utf-8'))
  for link in parser.links:
   if link.startswith('#') and link[1:] not in parser.ids:fails.append(f'{anchor_page}: missing fragment {link}')
 try:subprocess.run(['node','--check',str(ROOT/'assets/app.js')],check=True,capture_output=True)
 except Exception as e:fails.append(f'JavaScript syntax: {e}')
 try:
  import fitz
  pdf=fitz.open(ROOT/'assets/Jyotirmoy_Chakraborty_Public_CV.pdf')
  txt=''.join(page.get_text() for page in pdf)
  for private in ['6296588161','254351011']:
   if private in txt:fails.append('Private detail present in public CV')
 except ImportError:print('PDF privacy verification skipped (PyMuPDF not installed)')
 print('Audited',len(htmls),'HTML files; issues:',len(fails))
 for x in fails:print('FAIL',x)
 return 1 if fails else 0
if __name__=='__main__':sys.exit(audit())
