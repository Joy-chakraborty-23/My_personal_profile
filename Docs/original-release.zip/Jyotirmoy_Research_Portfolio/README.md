# Jyotirmoy Chakraborty — Academic & Engineering Portfolio

A source-backed, accessible-first, **static website with zero third-party JavaScript dependencies**. Built from a personal brief, résumé, October 2026 battery digital-twin scientific report, two certificates and checked GitHub project READMEs.

## Quick start (Windows, macOS or Linux)

1. Unzip the project and open `index.html` in your browser. **No package installation is required**.
2. For local web-server behaviour, open a terminal in this folder and run:

   ```bash
   python -m http.server 8000
   ```

3. Open `http://localhost:8000`. The homepage links to the rest of the site.

### Technology, explained simply

| Technical term | In plain English | Used here |
|---|---|---|
| Static-site generation | Creating complete web pages ahead of time, instead of asking a server to produce them every visit | `build_site.py` generates 17 HTML files |
| Responsive design | A layout that adjusts for mobile, tablet and desktop screens | `assets/styles.css` |
| Progressive enhancement | Keeping core content and navigation usable even without JavaScript | All pages are regular HTML |
| Client-side JavaScript | Small code snippets that run in a visitor's browser | Filters, dark mode, figure tabs, FAQ assistant |
| FAQ fallback | A guided question-answer tool using vetted, fixed answers rather than an AI API | `assets/app.js` |
| SEO metadata | Information that describes pages to search engines and social apps | Each HTML page has a title, description, and social image |
| Canonical URL / sitemap | A preferred web address and index of all pages | Generated when a real domain is configured |

## Folder map

```text
.
├── index.html                  homepage
├── about.html                  background and academic journey
├── research.html               research architecture and evidence
├── projects.html               searchable/filterable projects
├── projects/*.html             individual case studies (9)
├── experience.html             timeline, skills, verified certificates
├── publications.html           honest scholarly publication status
├── current-work.html           dated progress summaries
├── contact.html                email and verified profiles
├── data/content.json           EDIT THIS to update facts/projects
├── build_site.py               rebuilds all HTML pages
├── assets/styles.css           layout, colours, dark mode
├── assets/app.js               interaction and FAQ responses
├── assets/portrait.webp        supplied portrait
├── assets/*voltage.webp        actual figures from report
├── assets/*soc.webp            actual figures from report
├── assets/*temperature.webp    actual figures from report
├── assets/*current.webp        actual figures from report
├── assets/*Public_CV.pdf       privacy-reviewed CV
└── docs/                       audit, deployment and test notes
```

## Update your site without coding

**Update your biography**: Open `data/content.json` in Notepad or VS Code. Find `profile` → `summary`. Replace that sentence with your new introduction. Save the file. Run `python build_site.py`.

**Add a project**: Copy any object inside the `projects` array in `data/content.json`. Change its `slug` (lowercase hyphenated unique identifier), `title`, `category`, `tags`, `problem`, `role`, `method`, `outcome`, `limitation` and `source_note`. **Only use verifiable results**. Save and run `python build_site.py`. A new project HTML file and project card are automatically generated. Ensure each slug is unique and use valid JSON commas/quotes.

**Replace the CV**: Upload a new searchable-text PDF to `assets/Jyotirmoy_Chakraborty_Public_CV.pdf`. Avoid including phone numbers, roll numbers, home addresses or other sensitive details. If renaming, also update `profile.cv` in the JSON. Rebuild.

**Update current research**: Edit `current_work` in `data/content.json`, including `updated` dates. Rebuild. Note: the major research page is currently written in `build_site.py`; update that template if the scientific architecture or validation stage changes.

**Change FAQ answers**: Edit the `FAQs` definitions in `assets/app.js` to keep the portfolio guide aligned with approved content. This is intentionally a deterministic FAQ assistant; it is not a large language model or server-side retrieval system.

## What works immediately

- Seven-destination primary navigation plus a separate current-work page
- Responsive layouts, skip link, logical headings and keyboard-accessible controls
- Dark/light theme toggle, chosen theme stored locally in your browser
- Search/filter projects, figure tabs with keyboard arrow navigation
- Working local FAQ guide; safe fallback on unanswered questions
- Academic email links, copy-email interaction (clipboard API is browser-dependent)
- CV/certificate download links, verified external profile and code links
- Research diagrams and original report-figure images

## What needs more work before external publication

- **Deployment:** The site is a local, deployable artifact, not currently published on a verified live URL.
- **Full browser and screen-reader testing:** Automated static audits passed; actual Chrome/Safari/Firefox and assistive-technology testing is still needed (see `docs/QA.md`).
- **AI assistant:** The assistant is an offline FAQ system, not an LLM. Adding LLM-based retrieval safely requires a hosted backend, content moderation, abuse controls and secret management.
- **Charts:** Plot tabs are interactive and use authentic figures from the supplied report. Raw numeric measurements were not supplied, so hover-over measurement tools or trace manipulation are not fabricated.
- **Publications:** No peer-reviewed publication was verified. The site honestly labels the October 2026 item as a technical report.
- **Contact form:** No backend is configured; a working `mailto:` link is provided instead. A form should only be added after implementing validated delivery, abuse prevention and consent.
- **External profile stats:** LeetCode solve counts and live LinkedIn follower numbers are not claimed.

See `docs/CONTENT_AUDIT.md`, `docs/QA.md`, and `docs/DEPLOY.md` for specifics.
