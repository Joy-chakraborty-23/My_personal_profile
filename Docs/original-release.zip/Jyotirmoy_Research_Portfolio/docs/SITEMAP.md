# Sitemap / navigation hierarchy (maximum depth four)

**Level 1:** Home (`/index.html`)

**Level 2:** About, Research, Projects, Experience, Publications, Contact and Current Work.

**Level 3:** Individual project case studies, e.g. `/projects/battery-digital-twin.html`.

**Level 4:** In-page technical sections such as architecture, validation/results and research figures. These are anchors, not further nested pages.

No page requires Level 5 or a multi-level dropdown. The homepage offers prominent direct access to research, featured projects, the CV, contact and current work. Seven primary navigation destinations are used; Current Work has a separate direct link from the homepage, footer and mobile navigation.
